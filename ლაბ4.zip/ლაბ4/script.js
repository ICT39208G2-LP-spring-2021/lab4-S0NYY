
$(document).ready(function (){
    $('#loginButton').click(function (){
        $('#loginForm').toggleClass('visually-hidden');
    });
});

